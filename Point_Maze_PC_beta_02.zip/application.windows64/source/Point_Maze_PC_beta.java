import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Point_Maze_PC_beta extends PApplet {

/* Ersteller: Jonathan Litzelmann
 Mit freundlicher Unterstützung von Kai Krull*/


//Variablen
float cX;
float cY;
boolean start = true;
boolean debug = false;
int tStrokeColor = 0xff00ff00;
int tFillColor = 0xff00ff00;
int hStrokeColor = 0xffff0000;
int hFillColor = 0xffff0000;
int cStrokeColor = 0xffffffff;
int cFillColor = 0xffffffff;
int backgroundR = 0;
int backgroundG = 0;
int backgroundB = 0;
int timer = 0;
int win = 0;
int q = 30;
int s;
int cRadius;
PImage a;
PImage b;
PImage c;
PImage icon;

String[] save = new String[12];
String[] load = new String[12];

ArrayList<Level> levels = new ArrayList<Level>();
int level = 0;

public void setup() //<>//
{
  loadLevel(); //<>//
  
   //<>//
  frameRate(q); //<>//
  reset();
  orientation(LANDSCAPE);
  icon = loadImage("icon.png");
  surface.setIcon(icon);

  if (displayWidth == 1280)
  {
    s = 25;
  } else if (displayWidth == 1920)
  {
    s = 35;
  }
  //else if (displayWidth == )

  cRadius = PApplet.parseInt(s);

  a = loadImage("settings_button.jpg");
  a.resize(2*s, 2*s);
  b = loadImage("background.jpg");
  b.resize(displayWidth, displayHeight);

  ArrayList<Hindernis> h0 = new ArrayList<Hindernis>();
  ArrayList<Hindernis> h1 = new ArrayList<Hindernis>();
  ArrayList<Hindernis> h2 = new ArrayList<Hindernis>();
  ArrayList<Hindernis> h3 = new ArrayList<Hindernis>();
  ArrayList<Hindernis> h4 = new ArrayList<Hindernis>();
  ArrayList<Hindernis> h5 = new ArrayList<Hindernis>();
  ArrayList<Hindernis> h6 = new ArrayList<Hindernis>();
  ArrayList<Hindernis> h7 = new ArrayList<Hindernis>();
  //ArrayList<Hindernis> h8 = new ArrayList<Hindernis>();

  //Hindernisse level 0
  h0.add(new Hindernis(width / 2, 0, 50, height / 2 - 20));
  h0.add(new Hindernis(width / 2, height / 2 + 20, 50, height / 2 - 20));

  //Hindernisse level 1
  h1.add(new Hindernis(width / 2 - 25, 0, 50, height / 2 - 25));
  h1.add(new Hindernis(width / 2 - 25, height / 2 + 25, 50, height / 2 - 25));
  h1.add(new Hindernis(width / 2 - 150, height / 2 -25, 50, 50));

  //Hindernisse level 2
  h2.add(new Hindernis(width / 2 - 25, 0, 50, height / 2 - 25));
  h2.add(new Hindernis(width / 2 - 25, height / 2 + 25, 50, height / 2 - 25));
  h2.add(new Hindernis(width / 2 - 150, height / 4, 50, height / 2));
  h2.add(new Hindernis(100, height / 2 - 50, 50, 100));

  //Hindernisse level 3
  h3.add(new Hindernis(width / 2 - 25, 0, 50, height / 2 - 25));
  h3.add(new Hindernis(width / 2 - 25, height / 2 + 25, 50, height / 2 - 25));
  h3.add(new Hindernis(width / 2 - 150, height / 4, 50, height / 2));
  h3.add(new Hindernis(100, height / 2 - 50, width / 2 - 200, 100));

  //Hindernisse level 4
  h4.add(new Hindernis(width / 2 - 25, 0, 50, height / 2 - 25));
  h4.add(new Hindernis(width / 2 - 25, height / 2 + 25, 50, height / 2 - 25));
  h4.add(new Hindernis(width / 2 - 150, height / 4, 50, height / 2));
  h4.add(new Hindernis(100, height / 2 - 50, width / 2 - 200, 100));
  h4.add(new Hindernis(0, 0, width, height / 5));
  h4.add(new Hindernis(0, height / 5 * 4, width, width / 5));

  //Hindernisse level 5
  h5.add(new Hindernis(width / 2 - 25, 0, 50, height / 2 - 25));
  h5.add(new Hindernis(width / 2 - 25, height / 2 + 25, 50, height / 2 - 25));
  h5.add(new Hindernis(width / 2 - 150, height / 4, 50, height / 2));
  h5.add(new Hindernis(100, height / 2 - 50, width / 2 - 200, 100));
  h5.add(new Hindernis(0, 0, width, height / 5 ));
  h5.add(new Hindernis(0, height / 5 * 4, width, height / 5));
  h5.add(new Hindernis(width - 150, height / 5, 150, height / 5 * 3));
  h5.add(new Hindernis(300, height / 6, 50, height / 6));
  h5.add(new Hindernis(300, height / 3 * 2, 50, height / 6));

  //Hindernisse level 6
  h6.add(new Hindernis(width / 2 - 25, 0, 50, height / 2 - 25));
  h6.add(new Hindernis(width / 2 - 25, height / 2 + 25, 50, height / 2 - 25));
  h6.add(new Hindernis(width / 2 - 150, height / 4, 50, height / 2));
  h6.add(new Hindernis(100, height / 2 - 50, width / 2 - 200, 100));
  h6.add(new Hindernis(0, 0, width, height / 5 ));
  h6.add(new Hindernis(0, height / 5 * 4, width, height / 5));
  h6.add(new Hindernis(width - 150, height / 5, 150, height / 5 * 3));
  h6.add(new Hindernis(300, height / 6, 50, height / 6));
  h6.add(new Hindernis(300, height / 3 * 2, 50, height / 6));
  h6.add(new Hindernis(150, height / 4, 50, height / 2));

  //Hindernisse level 7
  h7.add(new Hindernis(width / 2 - 25, 0, 50, height / 2 - 25));
  h7.add(new Hindernis(width / 2 - 25, height / 2 + 25, 50, height / 2 - 25));
  h7.add(new Hindernis(width / 2 - 225, height / 4, width / 8, height / 2));
  h7.add(new Hindernis(100, height / 2 - 50, width / 2 - 200, 100));
  h7.add(new Hindernis(0, 0, width, height / 5 ));
  h7.add(new Hindernis(0, height / 5 * 4, width, height / 5));
  h7.add(new Hindernis(width - 150, height / 5, 150, height / 5 * 3));
  h7.add(new Hindernis(300, height / 6, 50, height / 6));
  h7.add(new Hindernis(300, height / 3 * 2, 50, height / 6));
  h7.add(new Hindernis(150, height / 4, 50, height / 2));

  //Hindernisse level 8
  //h8.add(new Hindernis(

  levels.add(new Level(h0));
  levels.add(new Level(h1));
  levels.add(new Level(h2));
  levels.add(new Level(h3));
  levels.add(new Level(h4));
  levels.add(new Level(h5));
  levels.add(new Level(h6));
  levels.add(new Level(h7));
  //levels.add(new Level(h8));
}

public void draw()
{
  frameRate(q);

  if (settings == false && pause == false && start == false)
  {

    float vX = cX - mouseX;
    float vY = cY - mouseY;
    float abstand = sqrt(vX * vX + vY * vY);

    timer++;
    if (timer == 59)
    {
      timer = 0;
    }

    if (abstand == 0)
    {
      abstand = 1.0f;
    }

    cX = cX + vX / abstand / abstand * 2500;
    cY = cY + vY / abstand / abstand * 2500;

    if (cX < 5.0f)
    {
      cX = 5.0f;
    }

    if (cX > width - 5.0f)
    {
      cX = width - 5.0f;
    }

    if (cY < 5.0f)
    {
      cY = 5.0f;
    }

    if (cY > height - 5.0f)
    {
      cY = height - 5.0f;
    }
  }

  levels.get(level).update();

  if (win == 1)
  {
    if (level < levels.size()-1)
    {
      level++;
      saveLevel();
    }
    reset();
  }

  if (win > 0)
  {
    win--;
  }

  background(backgroundR, backgroundG, backgroundB);

  levels.get(level).render();

  // Kreis
  fill(cFillColor);
  stroke(cStrokeColor);
  ellipse(cX, cY, 0.5f*s, 0.5f*s);

  if (win > 0)
  {
    fill(0xff00ff00);
    textSize(10*s);
    textAlign(CENTER, CENTER);
    text("WIN", width / 2, height / 2);
    textAlign(LEFT, BOTTOM);
  }

  if (start == true)
  {
    strokeWeight(3);
    stroke(255);
    fill(0);
    rect(0, 0, width-1, height-1);

    fill(0xffff0000);
    textSize(100);
    textAlign(CENTER, BOTTOM);
    text("POINT MAZE", width/2, 100);
    textAlign(CENTER, CENTER);
    text("Klicken zum starten", width/2, height/2);
    textAlign(LEFT, CENTER);

    if (mousePressed && mouseX < width-100 && mouseY > 100)
    {
      start = false;
    }
  }

  pause();

  settings_();

  if (!settings && !start)
  {
    noFill();
    strokeWeight(3);
    ellipse(width -25, 25, 50, 50);
  }

  if (pause == true && !start)
  {
    image(a, width - 100, 4, 40, 40);
    noFill();
    stroke(255);
    strokeWeight(3);
    ellipse(width - 80, 25, 50, 50);
  }

  if (debug == true)
  {
    text(timer, 10, 20);
  }

  if (win <= 100 && win > 0)
  {
    if (level == levels.size()-1)
    {
      //image(c, 0, 0, 1280, 720);
    }
  }
}

public void reset()
{
  cX = width * 0.75f;
  cY = height / 2;
}

public void win()
{
  if (win <= 0)
  {
    win = 120;
  }
  if (win > 115 || win < 110 && win > 105)
  {
  }
}

public void mouseClicked()
{
}

public void mousePressed()
{
  reset();
  if (settings == false && start == false)
  {
    if (mouseX > width - 50 && mouseX < width && mouseY > 0 && mouseY < 50)
    {
      pause = !pause;
    }
  }

  if (pause == true)
  {
    if (mouseX > width - 100 && mouseX < width - 50 && mouseY > 0 && mouseY < 50)
    {
      settings = !settings;
    }

    if (settings == true)
    {
    }
  }
}
boolean settings = false;

public void settings_()
{
  if(settings == true)
  {
    stroke(255);
    fill(backgroundR, backgroundG, backgroundB);
    rect(0, 0, width-1, height-1);
    fill(255);
    textSize(s);
    text("EINSTELLUNGEN", 10, 25);
    text("Design", 10, 65);
    
    text("Hintergrund", 10, 105);
    
    fill(0xffff0000);
    rect(10, 145, 70, 70);
    strokeWeight(10);
    stroke(255);
    line(45, 165, 45, 195);
    line(30, 180, 60, 180);
    if (mousePressed && mouseX < 80 && mouseX > 10 && mouseY < 215 && mouseY > 145)
    {
      backgroundR++;
    }
    strokeWeight(3);
    fill(0xffff0000);
    rect(10, 225, 70, 70);
    strokeWeight(10);
    stroke(255);
    line(30, 260, 60, 260);
    strokeWeight(3);
    if (mousePressed && mouseX < 80 && mouseX > 10 && mouseY < 295 && mouseY > 225)
    {
      backgroundR--;
    }
    if (backgroundR < 0)
    {
      backgroundR = 0;
    }
    if (backgroundR > 255)
    {
      backgroundR = 255;
    }
    fill(255);
    text(backgroundR, 10, 335);
    
    fill(0xff00ff00);
    rect(90, 145, 70, 70);
    if (mousePressed && mouseX < 160 && mouseX > 90 && mouseY < 215 && mouseY > 145)
    {
      backgroundG++;
    }
    strokeWeight(10);
    stroke(255);
    line(125, 165, 125, 195);
    line(110, 180, 140, 180);
    fill(0xff00ff00);
    strokeWeight(3);
    rect(90, 225, 70, 70);
    strokeWeight(10);
    stroke(255);
    fill(0xff00ff00);
    line(110, 260, 140, 260);
    strokeWeight(3);
    if (mousePressed && mouseX < 160 && mouseX > 90 && mouseY < 295 && mouseY > 225)
    {
      backgroundG--;
    }
    if (backgroundG < 0)
    {
      backgroundG = 0;
    }
    if (backgroundG > 255)
    {
      backgroundG = 255;
    }
    fill(255);
    text(backgroundG, 90, 335);
    
    fill(0xff0000ff);
    rect(170, 145, 70, 70);
    if (mousePressed && mouseX < 230 && mouseX > 170 && mouseY < 215 && mouseY > 145)
    {
      backgroundB++;
    }
    fill(0xff0000ff);
    rect(170, 225, 70, 70);
    strokeWeight(10);
    stroke(255);
    line(205, 165, 205, 195);
    line(190, 180, 220, 180);
    line(190, 260, 220, 260);
    strokeWeight(3);
    if (mousePressed && mouseX < 230 && mouseX > 170 && mouseY < 295 && mouseY > 225)
    {
      backgroundB--;
    }
    if (backgroundB < 0)
    {
      backgroundB = 0;
    }
    if (backgroundB > 255)
    {
      backgroundB = 255;
    }
    fill(255);
    text(backgroundB, 170, 335);
  }
  
  if(pause && !settings && !start)
  {
    fill(255);
    strokeJoin(ROUND);
    triangle(width - 35, 10, width - 35, 40, width - 10, 25);
    //reset();
  }
  else if(!pause && !settings && !start)
  {
    line(width - 30, 15, width - 30, 35);
    line(width - 20, 15, width - 20, 35);
    
    if(debug == true)
    {
      fill(255);
      textSize(10);
      text(round(frameRate), 0, 10);
    }
  }
}
class Hindernis
{
  private int x;
  private int y;
  private int h;
  private int b;
  
  public Hindernis(int posX, int posY, int breite, int hoehe)
  {
    this.x = posX;
    this.y = posY;
    this.b = breite;
    this.h = hoehe;
  }
  
  public void render()
  {
    fill(hFillColor);
    stroke(hStrokeColor);
    rect(this.x, this.y, this.b, this.h);
  }
  
  public boolean isPointInside(float cx, float cy)
  {
    if(cx-0.4f*cRadius < this.x + this.b && cx+0.4f*cRadius > this.x && cy-0.4f*cRadius < this.y + this.h && cy+0.4f*cRadius > this.y)
    {
      return true;
    }
    else
    {
      return false;
    }
  }
};
class Level
{
  private int startX = width / 4 * 3;
  private int startY = height / 2;
  private int zielX = 0;
  private int zielY = height / 2 - 20;
  private ArrayList<Hindernis> hindernisse;
  
  public Level(ArrayList<Hindernis> h)
  {
    this.hindernisse = h;
  }
  
  public void render()
  {
    stroke(tStrokeColor);
    fill(tFillColor);
    rect(this.zielX, this.zielY, 10, 40);
    
    //Hindernisse
    for(int i = 0; i < hindernisse.size(); i++)
    {
      Hindernis h = hindernisse.get(i);
      h.render();
    }
  }
  
  public void update()
  {
    if(cX < zielX + 10 && cX > zielX && cY < zielY + 40 && cY > zielY)
    {
      win();
      
    }
    
    for(int i = 0; i < hindernisse.size(); i++)
    {
      Hindernis h = hindernisse.get(i);
      if(h.isPointInside(cX, cY))
      {
        reset();
        //fail--;
      }
    }
    
    if(win > 0)
    {
      if(cX < zielX)
      {
        cX = zielX;
      }
      if(cX > zielX+10)
      {
        cX = zielX+10;
      }
      if(cY < zielY)
      {
        cY = zielY;
      }
       if(cY > zielY+40)    
      {
        cY = zielY+40;
      }
    }
  }
  
  public void reset()
  {
    cX = startX;
    cY = startY;
  }
};
boolean pause = false;

public void pause()
{
  if(pause == true)
  {
    stroke(255);
    fill(backgroundR, backgroundG, backgroundB);
    rect(0, 0, width-1, height-1);
    fill(255);
    textSize(s);
    textAlign(LEFT, CENTER);
    text("PAUSE", 10, 25);
    text("Der Kreis bwewegt sich immer von dem Finger weg,", 10, 25+s);
    text("und zwar schneller, wenn der Finger näher am Kreis ist.", 10, 25+2*s);
    text("Wenn der Kreis in einen roten Bereich eintritt, wird er zurückgesetzt.", 10, 25+3*s);
    text("Wenn er in den Grünen Bereich eintritt, hat man Gewonnen.", 10, 25+4*s);
    text("Wenn man gewonnen hat, wird nach 2 Sekunden das nächste Level geladen.", 10, 25+5*s);
    text("Ein Tippen setzt den Kreis zurück.", 10, 25+6*s);
    text("Tasten:", 10, 25+8*s);
    text("i", 10, 25+9*s);
    text(":", 70, 25+9*s);
    text("Zeigt diese Information an", 130, 25+9*s);
    text("ESC", 10, 25+10*s);
    text(":", 70, 25+10*s);
    text("Beendet das Programm", 130, 25+10*s);
    text("Finger:", 10, 25+12*s);
    text("Bewegung", 10, 25+13*s);
    text(":", 140, 25+13*s);
    text("Bewegung Kreis", 190, 25+13*s);
    text("Tippen", 10, 25+14*s);
    text(":", 140, 25+14*s);
    text("Kreis wird zurückgesetzt", 190, 25+14*s);
    textSize(14);
    text("PointMazePC v1.9.5", 10, height-25);
  }
}
public void loadLevel()
{
  load = loadStrings(dataPath("") + "\\save.txt");
  if (load != null)
  {
    debug = PApplet.parseBoolean(load[0]);
    tStrokeColor = unhex(load[1]);
    tFillColor = unhex(load[2]);
    hStrokeColor = unhex(load[3]);
    hFillColor = unhex(load[4]);
    cStrokeColor = unhex(load[5]);
    cFillColor = unhex(load[6]);
    backgroundR = PApplet.parseInt(load[7]);
    backgroundG = PApplet.parseInt(load[8]);
    backgroundB = PApplet.parseInt(load[9]);
    q = PApplet.parseInt(load[10]);
    level = PApplet.parseInt(load[11]);
  }
}
public void saveLevel()
{
  save[0] = str(debug);
  save[1] = hex(tStrokeColor);
  save[2] = hex(tFillColor);
  save[3] = hex(hStrokeColor);
  save[4] = hex(hFillColor);
  save[5] = hex(cStrokeColor);
  save[6] = hex(cFillColor);
  save[7] = str(backgroundR);
  save[8] = str(backgroundG);
  save[9] = str(backgroundB);
  save[10] = str(q);
  save[11] = str(level);
  saveStrings(dataPath("") + "\\save.txt", save);
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Point_Maze_PC_beta" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
